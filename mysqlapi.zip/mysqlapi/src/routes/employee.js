const router =require("express").Router();
const { getemployeelist,getemployeeid,postemployee,putemployee,deleteemployee} = require("../controllers/employee");


router.get("/",getemployeelist);

router.get('/:id',getemployeeid);

router.post('/',postemployee);

router.put('/:id',putemployee);

router.delete('/:id',deleteemployee);

module.exports=router;