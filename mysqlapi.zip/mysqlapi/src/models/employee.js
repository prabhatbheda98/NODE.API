module.exports =(Sequelize,sequelize) =>{
    const Employee = sequelize.define("Employee",{
        id:{
            type:Sequelize.INTEGER,
            primaryKey:true,
            autoIncrement:true,
        },
        fname:{
            type:Sequelize.STRING,
            allowNull:false
        },
        age:{
            type: Sequelize.INTEGER
        },
        city:{
            type:Sequelize.STRING
        },
        salary:{
            type:Sequelize.INTEGER
        }
    })
    return Employee;
}
